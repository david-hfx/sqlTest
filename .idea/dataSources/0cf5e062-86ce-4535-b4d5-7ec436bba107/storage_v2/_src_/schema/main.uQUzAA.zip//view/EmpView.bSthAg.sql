CREATE VIEW EmpView as    
select * from Employee;

